"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_scripts_services_ts"],{

/***/ 37222:
/*!*************************************!*\
  !*** ./src/app/scripts/services.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "services": () => (/* binding */ services)
/* harmony export */ });
const services = {};

/***/ })

}]);
//# sourceMappingURL=src_app_scripts_services_ts.js.map