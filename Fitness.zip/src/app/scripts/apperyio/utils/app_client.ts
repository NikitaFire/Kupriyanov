export var UtilsAppClient = {
};

export interface UtilsAppClientInterface {
};
